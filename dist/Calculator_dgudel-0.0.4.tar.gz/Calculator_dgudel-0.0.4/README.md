Welcome to the Calculator app!

The Calculator performs basic mathematical operations.

In order to get a result, please, enter one of the mathematical operators (+, -, *, /, ** or sqrt)
and a number, separated by a space. The result is kept in memory and you can proceed with next calculations on the basis of this intermediary result.

You can also take a quadratic root from the number in the result by entering sqrt'.

In order to reset the result, enter 'reset'.

If you want to stop the calculation get the final result and exit, enter 'quit'.